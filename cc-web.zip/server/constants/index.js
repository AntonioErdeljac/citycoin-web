const errorMessages = require('./errorMessages');

module.exports.errorMessages = errorMessages;
