const getById = require('./getById');
const verify = require('./verify');

module.exports.getById = getById;
module.exports.verify = verify;
