const getById = require('./getById');
const updateById = require('./updateById');

module.exports.getById = getById;
module.exports.updateById = updateById;
