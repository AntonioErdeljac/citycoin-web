const keyMirror = require('keymirror');

module.exports = keyMirror({
  day: null,
  hour: null,
  minute: null,
  month: null,
  week: null,
});
