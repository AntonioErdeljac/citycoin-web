const keyMirror = require('keymirror');

module.exports = keyMirror({
  AUTHENTICATION: null,
});
