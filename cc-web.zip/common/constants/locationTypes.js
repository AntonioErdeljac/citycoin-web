const keyMirror = require('keymirror');

module.exports = keyMirror({
  Point: null,
});
