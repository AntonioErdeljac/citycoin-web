const hr = require('./hr');

module.exports.hr = hr;

module.exports.SUPPORTED_LOCALES = ['hr'];
