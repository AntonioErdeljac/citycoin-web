const keyMirror = require('keymirror');

module.exports = keyMirror({
  ADMIN: null,
  REGULAR: null,
  SUPERVISOR: null,
});
