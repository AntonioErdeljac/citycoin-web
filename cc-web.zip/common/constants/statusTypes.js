const keyMirror = require('keymirror');

module.exports = keyMirror({
  DRAFT: null,
  PUBLISHED: null,
});
