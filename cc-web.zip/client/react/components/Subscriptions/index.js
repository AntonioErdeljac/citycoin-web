import Form from './Form';
import List from './List';

export default {
  Form,
  List,
};
